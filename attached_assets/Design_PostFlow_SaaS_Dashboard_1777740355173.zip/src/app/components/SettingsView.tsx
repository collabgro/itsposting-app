import { useState } from 'react';
import { ChevronRight, User, Bell, Key, Users, UserPlus, Link as LinkIcon, Tag, Upload as UploadIcon, CreditCard, Palette } from 'lucide-react';

export function SettingsView() {
  const [activeCategory, setActiveCategory] = useState('my-settings');
  const [activeTab, setActiveTab] = useState('my-settings');

  const categories = [
    {
      id: 'my-account',
      title: 'MY ACCOUNT',
      items: [
        { id: 'my-settings', icon: User, label: 'My settings' },
        { id: 'notifications', icon: Bell, label: 'Notifications' },
        { id: 'api-tokens', icon: Key, label: 'API tokens' }
      ]
    },
    {
      id: 'organization',
      title: 'ORGANIZATION',
      items: [
        { id: 'general', icon: Users, label: 'General' },
        { id: 'members', icon: UserPlus, label: 'Members' },
        { id: 'approving', icon: CheckSquare, label: 'Approving' },
        { id: 'social-accounts', icon: LinkIcon, label: 'Social accounts' },
        { id: 'groups', icon: Users, label: 'Groups' },
        { id: 'labels', icon: Tag, label: 'Labels' },
        { id: 'clickup', icon: CheckSquare, label: 'ClickUp' },
        { id: 'billing', icon: CreditCard, label: 'Billing' },
        { id: 'customizations', icon: Palette, label: 'Customizations' }
      ]
    }
  ];

  return (
    <div className="flex gap-6 h-[calc(100vh-120px)]">
      <div className="w-64 bg-card border border-border rounded-xl p-4 overflow-y-auto">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-medium text-foreground">Settings</h3>
          <button className="text-xs text-muted-foreground hover:text-foreground">
            Choose between categories
          </button>
        </div>

        {categories.map((category) => (
          <div key={category.id} className="mb-6">
            <div className="text-xs font-medium text-muted-foreground mb-2 px-3">
              {category.title}
            </div>
            <div className="space-y-1">
              {category.items.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-all text-sm ${
                      isActive
                        ? 'bg-muted text-foreground'
                        : 'text-muted-foreground hover:text-foreground hover:bg-muted/50'
                    }`}
                  >
                    <Icon size={16} />
                    <span className="flex-1 text-left">{item.label}</span>
                    {isActive && <ChevronRight size={16} />}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      <div className="flex-1 bg-card border border-border rounded-xl overflow-hidden">
        {activeTab === 'my-settings' && (
          <div className="p-6">
            <div className="mb-6">
              <h2 className="text-lg font-semibold text-foreground mb-1">My settings</h2>
              <p className="text-sm text-muted-foreground">Manage your preferences</p>
            </div>

            <div className="flex gap-8 border-b border-border mb-6">
              <button className="px-1 py-3 text-sm font-medium text-primary border-b-2 border-primary">
                Personal info
              </button>
              <button className="px-1 py-3 text-sm font-medium text-muted-foreground hover:text-foreground">
                Notifications
              </button>
              <button className="px-1 py-3 text-sm font-medium text-muted-foreground hover:text-foreground">
                API tokens
              </button>
            </div>

            <div className="max-w-2xl space-y-6">
              <div>
                <h3 className="text-base font-semibold text-foreground mb-4">Personal info</h3>
                <p className="text-sm text-muted-foreground mb-6">
                  Update your photo and personal details.
                </p>

                <div className="flex items-start gap-6 mb-6">
                  <div>
                    <div className="w-16 h-16 bg-gradient-to-br from-orange-400 to-orange-600 rounded-full flex items-center justify-center text-white text-xl font-semibold mb-2">
                      CG
                    </div>
                    <button className="text-xs text-primary hover:underline">Upload</button>
                  </div>
                  <div className="flex-1">
                    <div className="text-sm font-medium text-foreground mb-1">Upload image</div>
                    <div className="text-xs text-muted-foreground">Upload</div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Full name
                    </label>
                    <input
                      type="text"
                      defaultValue="Collab Gro"
                      className="w-full px-3 py-2 bg-input-background border border-input rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Phone
                    </label>
                    <input
                      type="tel"
                      placeholder="Enter phone number"
                      className="w-full px-3 py-2 bg-input-background border border-input rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Email
                    </label>
                    <input
                      type="email"
                      defaultValue="collabgroo@gmail.com"
                      className="w-full px-3 py-2 bg-input-background border border-input rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                  </div>
                </div>

                <div className="flex justify-end mt-6">
                  <button className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:opacity-90 transition-opacity">
                    Save
                  </button>
                </div>
              </div>

              <div className="pt-6 border-t border-border">
                <h3 className="text-base font-semibold text-foreground mb-4">
                  Two-Factor Authentication (2FA)
                </h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Manage your two-factor authentication settings.
                </p>

                <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                  <div>
                    <div className="text-sm font-medium text-foreground mb-1">
                      Enable two-factor authentication (TOTP)
                    </div>
                    <div className="text-xs text-muted-foreground">
                      Use an app to receive a temporary one-time passcode each time you log in.
                    </div>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" className="sr-only peer" />
                    <div className="w-11 h-6 bg-switch-background peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-ring rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
                  </label>
                </div>
              </div>

              <div className="pt-6 border-t border-border">
                <h3 className="text-base font-semibold text-foreground mb-4">
                  Data & time formats
                </h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Choose the format for displaying dates and times.
                </p>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      First day of the week
                    </label>
                    <select className="w-full px-3 py-2 bg-input-background border border-input rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-ring">
                      <option>Sunday</option>
                      <option>Monday</option>
                    </select>
                    <p className="text-xs text-muted-foreground mt-1">
                      Set the first day of the week for the date picker and calendar.
                    </p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Date format
                    </label>
                    <select className="w-full px-3 py-2 bg-input-background border border-input rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-ring">
                      <option>MM/DD/YYYY</option>
                      <option>DD/MM/YYYY</option>
                      <option>YYYY-MM-DD</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab !== 'my-settings' && (
          <div className="flex items-center justify-center h-full">
            <div className="text-center">
              <div className="text-6xl mb-4 opacity-20">⚙️</div>
              <h3 className="text-lg font-semibold text-foreground mb-2">Coming Soon</h3>
              <p className="text-sm text-muted-foreground">This section is under development</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

import { CheckSquare } from 'lucide-react';
