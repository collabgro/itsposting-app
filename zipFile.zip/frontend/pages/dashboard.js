import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import {
  Sparkles, BarChart3, Calendar as CalendarIcon,
  CheckCircle, Heart, Loader2, Trash2, RefreshCw,
} from 'lucide-react';
import Layout from '../components/Layout';
import ContentCreatorModal from '../components/ContentCreatorModal';
import { postsAPI, authAPI } from '../lib/api';
import { useAuthStore } from '../lib/store';
import { format } from 'date-fns';
import toast from 'react-hot-toast';

const CONTENT_TYPE_EMOJIS = {
  static: '💬',
  photo: '📷',
  carousel: '📊',
  video: '🎥',
};

export default function Dashboard() {
  const router = useRouter();
  const { user, updateUser, isAuthenticated } = useAuthStore();

  const [stats, setStats] = useState(null);
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreator, setShowCreator] = useState(false);

  useEffect(() => {
    if (!isAuthenticated) {
      router.push('/login');
      return;
    }
    loadData();
  }, [isAuthenticated]);

  const loadData = async () => {
    try {
      const [statsRes, postsRes, profileRes] = await Promise.all([
        postsAPI.getAnalytics().catch(() => ({ data: {} })),
        postsAPI.getAll({ limit: 10 }).catch(() => ({ data: [] })),
        authAPI.verify().catch(() => null),
      ]);

      setStats(statsRes.data);
      setPosts(postsRes.data);
      
      if (profileRes?.data?.customer) {
        updateUser(profileRes.data.customer);
      }
    } catch (error) {
      console.error('Failed to load dashboard:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!confirm('Delete this post?')) return;
    try {
      await postsAPI.delete(id);
      toast.success('Post deleted');
      loadData();
    } catch (error) {
      toast.error('Failed to delete');
    }
  };

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[400px]">
          <Loader2 className="w-12 h-12 text-primary-500 animate-spin" />
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              Welcome back, {user?.business_name || 'there'}!
            </h1>
            <p className="text-gray-600 mt-1">Your social media command center</p>
          </div>
          <button
            onClick={() => setShowCreator(true)}
            className="btn btn-primary"
          >
            <Sparkles className="w-4 h-4 mr-2" />
            Create Post
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <StatCard
            label="Total Posts"
            value={stats?.total_posts || 0}
            icon={BarChart3}
            color="blue"
          />
          <StatCard
            label="Scheduled"
            value={stats?.scheduled_count || 0}
            icon={CalendarIcon}
            color="yellow"
          />
          <StatCard
            label="Published"
            value={stats?.posted_count || 0}
            icon={CheckCircle}
            color="green"
          />
          <StatCard
            label="Engagement"
            value={stats?.total_likes || 0}
            icon={Heart}
            color="purple"
          />
        </div>

        {/* Quick Create */}
        <div className="card p-6">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h2 className="text-xl font-bold text-gray-900">🎨 Create Custom Post</h2>
              <p className="text-sm text-gray-600 mt-1">AI generates content from your prompt</p>
            </div>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { type: 'static', label: 'Text Card', credits: 1, emoji: '💬' },
              { type: 'photo', label: 'Photo', credits: 3, emoji: '📷' },
              { type: 'carousel', label: 'Carousel', credits: 5, emoji: '📊' },
              { type: 'video', label: 'Video', credits: 10, emoji: '🎥' },
            ].map((item) => (
              <button
                key={item.type}
                onClick={() => setShowCreator(true)}
                className="p-4 border-2 border-gray-200 rounded-lg hover:border-primary-500 hover:bg-primary-50 transition-all text-center"
              >
                <div className="text-2xl mb-1">{item.emoji}</div>
                <div className="font-medium text-sm">{item.label}</div>
                <div className="text-xs text-gray-500 font-mono">{item.credits} credits</div>
              </button>
            ))}
          </div>
        </div>

        {/* Recent Posts */}
        <div className="card">
          <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
            <h2 className="text-xl font-bold text-gray-900">Recent Posts</h2>
            <button
              onClick={() => router.push('/calendar')}
              className="text-sm text-primary-600 hover:text-primary-700 font-medium"
            >
              View Calendar →
            </button>
          </div>

          {posts.length === 0 ? (
            <div className="p-12 text-center">
              <CalendarIcon className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-600 mb-4">No posts yet</p>
              <button
                onClick={() => setShowCreator(true)}
                className="btn btn-primary"
              >
                <Sparkles className="w-4 h-4 mr-2" />
                Create Your First Post
              </button>
            </div>
          ) : (
            <div className="divide-y divide-gray-200">
              {posts.map((post) => (
                <div key={post.id} className="p-6 hover:bg-gray-50 transition-colors">
                  <div className="flex gap-4">
                    {/* Preview */}
                    <div className="flex-shrink-0">
                      {post.media_url ? (
                        <img
                          src={post.media_url}
                          alt=""
                          className="w-20 h-20 object-cover rounded-lg"
                          onError={(e) => { e.target.style.display = 'none'; }}
                        />
                      ) : (
                        <div className="w-20 h-20 bg-gray-200 rounded-lg flex items-center justify-center text-2xl">
                          {CONTENT_TYPE_EMOJIS[post.content_type] || '📝'}
                        </div>
                      )}
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-medium capitalize">
                            {CONTENT_TYPE_EMOJIS[post.content_type]} {post.content_type}
                          </span>
                          <span
                            className={`px-2 py-0.5 text-xs font-medium rounded-full ${
                              post.status === 'posted'
                                ? 'bg-green-100 text-green-800'
                                : post.status === 'scheduled'
                                ? 'bg-yellow-100 text-yellow-800'
                                : 'bg-gray-100 text-gray-800'
                            }`}
                          >
                            {post.status}
                          </span>
                          {post.image_provider && (
                            <span className="text-xs text-gray-500">
                              via {post.image_provider}
                            </span>
                          )}
                        </div>
                        <button
                          onClick={() => handleDelete(post.id)}
                          className="text-gray-400 hover:text-error-500"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                      <p className="text-gray-700 line-clamp-2 text-sm">{post.caption}</p>
                      <p className="text-xs text-gray-500 mt-1">
                        {post.scheduled_date
                          ? `Scheduled: ${format(new Date(post.scheduled_date), 'MMM d, h:mm a')}`
                          : `Created: ${format(new Date(post.created_at), 'MMM d')}`}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {showCreator && (
        <ContentCreatorModal
          onClose={() => setShowCreator(false)}
          onSuccess={() => {
            setShowCreator(false);
            loadData();
          }}
        />
      )}
    </Layout>
  );
}

function StatCard({ label, value, icon: Icon, color }) {
  const colors = {
    blue: 'border-l-primary-500',
    yellow: 'border-l-warning-500',
    green: 'border-l-success-500',
    purple: 'border-l-accent-500',
  };

  return (
    <div className={`card border-l-4 ${colors[color]} p-4`}>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs font-medium text-gray-600 uppercase">{label}</p>
          <p className="text-2xl font-bold text-gray-900 mt-1">{value}</p>
        </div>
        {Icon && <Icon className="w-8 h-8 text-gray-300" />}
      </div>
    </div>
  );
}
