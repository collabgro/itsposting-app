import { useState } from 'react';
import { ThemeProvider } from './components/ThemeProvider';
import { Sidebar } from './components/Sidebar';
import { TopBar } from './components/TopBar';
import { DashboardView } from './components/DashboardView';
import { CalendarView } from './components/CalendarView';
import { SettingsView } from './components/SettingsView';
import { ContentCreatorModal } from './components/ContentCreatorModal';

function AppContent() {
  const [activeView, setActiveView] = useState('dashboard');
  const [showModal, setShowModal] = useState(false);

  const renderView = () => {
    switch (activeView) {
      case 'dashboard':
        return <DashboardView onCreatePost={() => setShowModal(true)} />;
      case 'publishing':
        return <CalendarView />;
      case 'settings':
        return <SettingsView />;
      case 'analytics':
      case 'drafts':
      case 'media':
        return (
          <div className="flex items-center justify-center h-96">
            <div className="text-center">
              <div className="text-6xl mb-4 opacity-20">🚧</div>
              <h3 className="text-xl font-semibold text-foreground mb-2">Coming Soon</h3>
              <p className="text-muted-foreground">This section is under development</p>
            </div>
          </div>
        );
      default:
        return <DashboardView onCreatePost={() => setShowModal(true)} />;
    }
  };

  const getViewInfo = () => {
    switch (activeView) {
      case 'dashboard':
        return { title: 'Dashboard', subtitle: 'Welcome back' };
      case 'analytics':
        return { title: 'Analytics', subtitle: 'Content & profiles analytics' };
      case 'publishing':
        return { title: 'Publishing', subtitle: 'Schedule and manage posts' };
      case 'drafts':
        return { title: 'Drafts', subtitle: 'Unscheduled posts or posts without selected accounts' };
      case 'media':
        return { title: 'Media library', subtitle: '0 MB / 100 GB used' };
      case 'settings':
        return { title: 'Settings', subtitle: 'Manage your preferences' };
      default:
        return { title: 'Dashboard', subtitle: 'Welcome back' };
    }
  };

  const viewInfo = getViewInfo();

  return (
    <div className="flex h-screen bg-background">
      <Sidebar activeView={activeView} onNavigate={setActiveView} />

      <div className="flex-1 flex flex-col overflow-hidden">
        <TopBar
          title={viewInfo.title}
          subtitle={viewInfo.subtitle}
          onCreatePost={activeView === 'dashboard' ? () => setShowModal(true) : undefined}
        />

        <div className="flex-1 overflow-y-auto p-6">
          {renderView()}
        </div>
      </div>

      {showModal && <ContentCreatorModal onClose={() => setShowModal(false)} />}
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AppContent />
    </ThemeProvider>
  );
}