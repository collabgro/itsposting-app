import { useState } from 'react';
import { useRouter } from 'next/router';
import Link from 'next/link';
import { Sparkles, Building2, MapPin, Check, Loader2 } from 'lucide-react';
import { authAPI } from '../lib/api';
import { useAuthStore } from '../lib/store';
import toast from 'react-hot-toast';

const INDUSTRIES = [
  'Concrete & Masonry', 'Plumbing', 'HVAC', 'Landscaping',
  'Roofing', 'Electrical', 'Painting', 'Carpentry',
  'General Contracting', 'Other',
];

export default function Signup() {
  const router = useRouter();
  const login = useAuthStore((state) => state.login);

  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    businessName: '',
    industry: '',
    location: '',
    email: '',
    password: '',
  });

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (step === 1) {
      if (!formData.businessName || !formData.industry || !formData.location) {
        toast.error('Please fill in all fields');
        return;
      }
      setStep(2);
      return;
    }

    setLoading(true);
    try {
      const response = await authAPI.register({
        email: formData.email,
        password: formData.password,
        businessName: formData.businessName,
        industry: formData.industry.toLowerCase().replace(/\s+&\s+/g, '_').replace(/\s+/g, '_'),
        location: formData.location,
      });

      const { customer, token } = response.data;
      login(customer, token);

      toast.success('Account created! Welcome to PostFlow 🎉');
      setTimeout(() => router.push('/dashboard'), 500);
    } catch (error) {
      toast.error(error.response?.data?.error || 'Signup failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Logo */}
        <div className="flex items-center justify-center gap-3 text-primary-600 mb-8">
          <Sparkles className="w-10 h-10" />
          <h1 className="text-3xl font-bold">PostFlow</h1>
        </div>

        {/* Progress */}
        <div className="mb-8 flex justify-center gap-2">
          {[1, 2].map((s) => (
            <div
              key={s}
              className={`h-2 w-16 rounded-full transition-all ${
                step >= s ? 'bg-primary-500' : 'bg-gray-200'
              }`}
            />
          ))}
        </div>

        <div className="bg-white rounded-lg shadow-card p-8">
          <form onSubmit={handleSubmit}>
            {step === 1 && (
              <div className="space-y-6 animate-fade-in">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">Tell us about your business</h2>
                  <p className="text-gray-600 mt-1">We'll customize content for you</p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Business Name</label>
                  <div className="relative">
                    <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="text"
                      required
                      className="input pl-10"
                      placeholder="ABC Plumbing"
                      value={formData.businessName}
                      onChange={(e) => setFormData({ ...formData, businessName: e.target.value })}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Industry</label>
                  <select
                    required
                    className="input"
                    value={formData.industry}
                    onChange={(e) => setFormData({ ...formData, industry: e.target.value })}
                  >
                    <option value="">Select your industry</option>
                    {INDUSTRIES.map((ind) => (
                      <option key={ind} value={ind}>{ind}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Location</label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="text"
                      required
                      className="input pl-10"
                      placeholder="Austin, TX"
                      value={formData.location}
                      onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    />
                  </div>
                </div>

                <button type="submit" className="btn btn-primary w-full">
                  Continue
                </button>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-6 animate-fade-in">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">Create your account</h2>
                  <p className="text-gray-600 mt-1">Start your 7-day free trial</p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                  <input
                    type="email"
                    required
                    className="input"
                    placeholder="you@company.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Password</label>
                  <input
                    type="password"
                    required
                    minLength={8}
                    className="input"
                    placeholder="At least 8 characters"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  />
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-blue-800">
                      <strong>10 free credits included!</strong>
                      <p className="text-blue-700 mt-1">Generate posts immediately with NanoBanana AI</p>
                    </div>
                  </div>
                </div>

                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="btn btn-secondary"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    disabled={loading}
                    className="btn btn-primary flex-1 disabled:opacity-50"
                  >
                    {loading ? (
                      <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Creating...</>
                    ) : (
                      'Create Account'
                    )}
                  </button>
                </div>
              </div>
            )}
          </form>

          {step === 1 && (
            <p className="mt-6 text-center text-gray-600 text-sm">
              Already have an account?{' '}
              <Link href="/login" className="text-primary-600 font-medium hover:text-primary-700">
                Sign in
              </Link>
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
