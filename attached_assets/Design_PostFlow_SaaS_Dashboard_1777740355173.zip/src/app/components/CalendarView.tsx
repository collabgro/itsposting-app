import { ChevronLeft, ChevronRight, Calendar, MapPin, Filter, Settings as SettingsIcon, Bell } from 'lucide-react';

export function CalendarView() {
  const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const weeks = [
    [26, 27, 28, 29, 30, 1, 2],
    [3, 4, 5, 6, 7, 8, 9],
    [10, 11, 12, 13, 14, 15, 16],
    [17, 18, 19, 20, 21, 22, 23],
    [24, 25, 26, 27, 28, 29, 30],
    [31, 1, 2, 3, 4, 5, 6]
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button className="p-2 hover:bg-muted rounded-lg transition-colors">
            <ChevronLeft size={20} className="text-foreground" />
          </button>

          <div className="flex items-center gap-3">
            <h2 className="text-lg font-semibold text-foreground">May 2026</h2>
            <button className="p-1.5 hover:bg-muted rounded transition-colors">
              <Calendar size={16} className="text-muted-foreground" />
            </button>
          </div>

          <button className="p-2 hover:bg-muted rounded-lg transition-colors">
            <ChevronRight size={20} className="text-foreground" />
          </button>

          <button className="px-3 py-1.5 bg-muted text-foreground rounded-lg text-sm hover:bg-muted/80 transition-colors">
            Today
          </button>

          <button className="flex items-center gap-2 px-3 py-1.5 bg-muted text-foreground rounded-lg text-sm hover:bg-muted/80 transition-colors">
            <MapPin size={14} />
            <span>Asia/Karachi</span>
          </button>
        </div>

        <div className="flex items-center gap-3">
          <button className="px-3 py-1.5 bg-muted text-foreground rounded-lg text-sm hover:bg-muted/80 transition-colors">
            Week
          </button>
          <button className="px-3 py-1.5 text-muted-foreground rounded-lg text-sm hover:bg-muted transition-colors">
            Month
          </button>
          <button className="px-3 py-1.5 text-muted-foreground rounded-lg text-sm hover:bg-muted transition-colors">
            List
          </button>

          <div className="w-px h-6 bg-border"></div>

          <button className="px-3 py-1.5 text-muted-foreground rounded-lg text-sm hover:bg-muted transition-colors">
            All labels
          </button>

          <button className="p-2 hover:bg-muted rounded-lg transition-colors">
            <Filter size={18} className="text-muted-foreground" />
          </button>

          <button className="p-2 hover:bg-muted rounded-lg transition-colors">
            <SettingsIcon size={18} className="text-muted-foreground" />
          </button>

          <button className="p-2 hover:bg-muted rounded-lg transition-colors">
            <Bell size={18} className="text-muted-foreground" />
          </button>

          <button className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:opacity-90 transition-opacity flex items-center gap-2">
            <div className="w-4 h-4 rounded-full border-2 border-current flex items-center justify-center">
              <span className="text-xs">+</span>
            </div>
            <span className="text-sm">New post</span>
          </button>
        </div>
      </div>

      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="grid grid-cols-7 border-b border-border">
          {daysOfWeek.map((day, idx) => (
            <div
              key={day}
              className={`p-4 text-center border-r border-border last:border-r-0 ${
                idx === 6 ? 'bg-primary/5' : ''
              }`}
            >
              <div className="text-sm font-medium text-foreground">{day}</div>
            </div>
          ))}
        </div>

        {weeks.map((week, weekIdx) => (
          <div key={weekIdx} className="grid grid-cols-7">
            {week.map((day, dayIdx) => {
              const isCurrentMonth = (weekIdx === 0 && day > 20) || (weekIdx === 5 && day < 10) ? false : true;
              const isSaturday = dayIdx === 6;

              return (
                <div
                  key={`${weekIdx}-${dayIdx}`}
                  className={`min-h-[120px] p-3 border-r border-b border-border last:border-r-0 ${
                    !isCurrentMonth ? 'bg-muted/20' : ''
                  } ${isSaturday ? 'bg-primary/5' : ''} hover:bg-muted/50 transition-colors cursor-pointer`}
                >
                  <div className={`text-sm ${isCurrentMonth ? 'text-foreground' : 'text-muted-foreground'}`}>
                    {day}
                  </div>
                </div>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
}
