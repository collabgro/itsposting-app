import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import { ChevronLeft, ChevronRight, Plus, Loader2 } from 'lucide-react';
import Layout from '../components/Layout';
import ContentCreatorModal from '../components/ContentCreatorModal';
import { postsAPI } from '../lib/api';
import { useAuthStore } from '../lib/store';
import {
  format, startOfMonth, endOfMonth, eachDayOfInterval,
  isSameDay, addMonths, subMonths, startOfWeek, endOfWeek,
} from 'date-fns';
import toast from 'react-hot-toast';

const EMOJIS = { static: '💬', photo: '📷', carousel: '📊', video: '🎥' };

export default function Calendar() {
  const router = useRouter();
  const { isAuthenticated } = useAuthStore();

  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreator, setShowCreator] = useState(false);

  useEffect(() => {
    if (!isAuthenticated) {
      router.push('/login');
      return;
    }
    loadPosts();
  }, [isAuthenticated, currentMonth]);

  const loadPosts = async () => {
    try {
      const res = await postsAPI.getAll({ limit: 100 });
      setPosts(res.data);
    } catch (error) {
      toast.error('Failed to load posts');
    } finally {
      setLoading(false);
    }
  };

  // Calculate calendar grid (with leading/trailing days)
  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const calendarStart = startOfWeek(monthStart);
  const calendarEnd = endOfWeek(monthEnd);
  const days = eachDayOfInterval({ start: calendarStart, end: calendarEnd });

  const getPostsForDay = (day) =>
    posts.filter((p) => p.scheduled_date && isSameDay(new Date(p.scheduled_date), day));

  return (
    <Layout>
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Calendar</h1>
            <p className="text-gray-600 mt-1">Schedule and manage your posts</p>
          </div>
          <button onClick={() => setShowCreator(true)} className="btn btn-primary">
            <Plus className="w-4 h-4 mr-2" />
            Create Post
          </button>
        </div>

        <div className="card">
          <div className="flex items-center justify-between p-6 border-b border-gray-200">
            <h2 className="text-2xl font-bold text-gray-900">
              {format(currentMonth, 'MMMM yyyy')}
            </h2>
            <div className="flex gap-2">
              <button
                onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}
                className="p-2 hover:bg-gray-100 rounded-lg"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                onClick={() => setCurrentMonth(new Date())}
                className="px-4 py-2 text-sm hover:bg-gray-100 rounded-lg"
              >
                Today
              </button>
              <button
                onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}
                className="p-2 hover:bg-gray-100 rounded-lg"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>

          {loading ? (
            <div className="p-12 text-center">
              <Loader2 className="w-8 h-8 text-primary-500 animate-spin mx-auto" />
            </div>
          ) : (
            <div className="p-6">
              {/* Day headers */}
              <div className="grid grid-cols-7 gap-2 mb-2">
                {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
                  <div key={day} className="text-center text-xs font-semibold text-gray-500 uppercase py-2">
                    {day}
                  </div>
                ))}
              </div>

              {/* Calendar grid */}
              <div className="grid grid-cols-7 gap-2">
                {days.map((day) => {
                  const dayPosts = getPostsForDay(day);
                  const isCurrentMonth = day.getMonth() === currentMonth.getMonth();
                  const isToday = isSameDay(day, new Date());

                  return (
                    <div
                      key={day.toString()}
                      className={`min-h-[100px] p-2 border-2 rounded-lg transition-all ${
                        !isCurrentMonth
                          ? 'border-gray-100 bg-gray-50 opacity-50'
                          : isToday
                          ? 'border-primary-500 bg-primary-50'
                          : 'border-gray-200 hover:border-gray-300 bg-white'
                      }`}
                    >
                      <div className={`text-xs font-medium mb-1 ${isToday ? 'text-primary-600' : 'text-gray-700'}`}>
                        {format(day, 'd')}
                      </div>

                      <div className="space-y-1">
                        {dayPosts.slice(0, 3).map((post) => (
                          <div
                            key={post.id}
                            className="text-xs bg-white border border-gray-200 rounded px-1.5 py-0.5 truncate"
                            title={post.caption}
                          >
                            <span className="mr-1">{EMOJIS[post.content_type]}</span>
                            {format(new Date(post.scheduled_date), 'h:mm a')}
                          </div>
                        ))}
                        {dayPosts.length > 3 && (
                          <div className="text-xs text-gray-500 text-center">
                            +{dayPosts.length - 3} more
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>

      {showCreator && (
        <ContentCreatorModal
          onClose={() => setShowCreator(false)}
          onSuccess={() => {
            setShowCreator(false);
            loadPosts();
          }}
        />
      )}
    </Layout>
  );
}
