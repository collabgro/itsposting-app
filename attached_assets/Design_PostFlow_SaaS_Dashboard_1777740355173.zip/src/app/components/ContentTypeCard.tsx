interface ContentTypeCardProps {
  icon: string;
  label: string;
  credits: number;
  color: 'green' | 'blue' | 'purple' | 'orange';
  onClick: () => void;
}

const colorStyles = {
  green: {
    badge: 'bg-emerald-100 text-emerald-700 border-emerald-200',
    gradient: 'from-emerald-50/50 to-transparent'
  },
  blue: {
    badge: 'bg-blue-100 text-blue-700 border-blue-200',
    gradient: 'from-blue-50/50 to-transparent'
  },
  purple: {
    badge: 'bg-purple-100 text-purple-700 border-purple-200',
    gradient: 'from-purple-50/50 to-transparent'
  },
  orange: {
    badge: 'bg-orange-100 text-orange-700 border-orange-200',
    gradient: 'from-orange-50/50 to-transparent'
  }
};

export function ContentTypeCard({ icon, label, credits, color, onClick }: ContentTypeCardProps) {
  const styles = colorStyles[color];

  return (
    <button
      onClick={onClick}
      className="relative flex-1 bg-white border border-gray-200 rounded-2xl p-6 hover:shadow-lg transition-all hover:-translate-y-1 group"
    >
      <div className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${styles.gradient} opacity-0 group-hover:opacity-100 transition-opacity`} />

      <div className="relative flex flex-col items-center gap-4">
        <div className="text-5xl">{icon}</div>
        <div className="text-center">
          <div className="font-semibold text-gray-900 mb-2">{label}</div>
          <div className={`inline-block px-3 py-1 rounded-full text-xs font-medium border ${styles.badge}`}>
            {credits} credit{credits > 1 ? 's' : ''}
          </div>
        </div>
      </div>
    </button>
  );
}
