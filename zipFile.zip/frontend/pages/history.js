import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import { Heart, MessageCircle, Share2, Loader2 } from 'lucide-react';
import Layout from '../components/Layout';
import { postsAPI } from '../lib/api';
import { useAuthStore } from '../lib/store';
import { format } from 'date-fns';

export default function History() {
  const router = useRouter();
  const { isAuthenticated } = useAuthStore();

  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    if (!isAuthenticated) {
      router.push('/login');
      return;
    }
    loadPosts();
  }, [isAuthenticated, filter]);

  const loadPosts = async () => {
    try {
      const params = filter === 'all' ? {} : { status: filter };
      const res = await postsAPI.getAll(params);
      setPosts(res.data);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const filters = [
    { id: 'all', label: 'All Posts' },
    { id: 'posted', label: 'Published' },
    { id: 'scheduled', label: 'Scheduled' },
    { id: 'draft', label: 'Drafts' },
  ];

  return (
    <Layout>
      <div className="max-w-5xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Post History</h1>
          <p className="text-gray-600 mt-1">All your generated content</p>
        </div>

        <div className="flex gap-2 overflow-x-auto pb-2">
          {filters.map((f) => (
            <button
              key={f.id}
              onClick={() => setFilter(f.id)}
              className={`px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap ${
                filter === f.id
                  ? 'bg-primary-500 text-white'
                  : 'bg-white border border-gray-200 text-gray-700 hover:bg-gray-50'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="card p-12 text-center">
            <Loader2 className="w-8 h-8 text-primary-500 animate-spin mx-auto" />
          </div>
        ) : posts.length === 0 ? (
          <div className="card p-12 text-center text-gray-600">
            No posts found
          </div>
        ) : (
          <div className="space-y-4">
            {posts.map((post) => (
              <div key={post.id} className="card p-4 sm:p-6">
                <div className="flex flex-col sm:flex-row gap-4">
                  {post.media_url && (
                    <img
                      src={post.media_url}
                      alt=""
                      className="w-full sm:w-32 h-32 object-cover rounded-lg"
                      onError={(e) => { e.target.style.display = 'none'; }}
                    />
                  )}

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2 flex-wrap">
                      <span className="text-sm font-medium capitalize">
                        {post.content_type}
                      </span>
                      <span
                        className={`px-2 py-0.5 text-xs font-medium rounded-full ${
                          post.status === 'posted'
                            ? 'bg-green-100 text-green-800'
                            : post.status === 'scheduled'
                            ? 'bg-yellow-100 text-yellow-800'
                            : 'bg-gray-100 text-gray-800'
                        }`}
                      >
                        {post.status}
                      </span>
                      {post.image_provider && (
                        <span className="text-xs text-gray-500 bg-gray-100 px-2 py-0.5 rounded">
                          {post.image_provider}
                        </span>
                      )}
                    </div>

                    <p className="text-gray-700 mb-3 line-clamp-3">{post.caption}</p>

                    <div className="flex items-center gap-4 text-sm text-gray-500">
                      <span>{format(new Date(post.created_at), 'MMM d, yyyy')}</span>
                      {post.engagement && (
                        <>
                          <span className="flex items-center gap-1">
                            <Heart className="w-4 h-4" />
                            {post.engagement.likes || 0}
                          </span>
                          <span className="flex items-center gap-1">
                            <MessageCircle className="w-4 h-4" />
                            {post.engagement.comments || 0}
                          </span>
                          <span className="flex items-center gap-1">
                            <Share2 className="w-4 h-4" />
                            {post.engagement.shares || 0}
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
}
