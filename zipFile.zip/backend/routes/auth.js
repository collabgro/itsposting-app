const express = require('express');
const bcrypt = require('bcryptjs');
const { generateToken, authenticate } = require('../middleware/auth');

module.exports = (pool) => {
  const router = express.Router();

  /**
   * POST /api/auth/register
   */
  router.post('/register', async (req, res) => {
    try {
      const { email, password, businessName, industry, location } = req.body;

      if (!email || !password || !businessName) {
        return res.status(400).json({ error: 'Missing required fields' });
      }

      if (password.length < 8) {
        return res.status(400).json({ error: 'Password must be at least 8 characters' });
      }

      // Check if email exists
      const existing = await pool.query('SELECT id FROM customers WHERE email = $1', [email]);
      if (existing.rows.length > 0) {
        return res.status(409).json({ error: 'Email already registered' });
      }

      // Hash password
      const passwordHash = await bcrypt.hash(password, 10);

      // Create customer
      const result = await pool.query(
        `INSERT INTO customers (email, password_hash, business_name, industry, location)
         VALUES ($1, $2, $3, $4, $5)
         RETURNING id, email, business_name, industry, location, plan, credits_balance, status`,
        [email, passwordHash, businessName, industry || 'other', location || '']
      );

      const customer = result.rows[0];
      const token = generateToken(customer.id, customer.email);

      // Log signup bonus
      await pool.query(
        `INSERT INTO credit_transactions (customer_id, transaction_type, amount, balance_after, description)
         VALUES ($1, 'bonus', 10, 10, 'Welcome bonus - 10 free credits')`,
        [customer.id]
      );

      res.json({
        customer,
        token,
      });
    } catch (error) {
      console.error('Register error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  /**
   * POST /api/auth/login
   */
  router.post('/login', async (req, res) => {
    try {
      const { email, password } = req.body;

      if (!email || !password) {
        return res.status(400).json({ error: 'Email and password required' });
      }

      const result = await pool.query('SELECT * FROM customers WHERE email = $1', [email]);

      if (result.rows.length === 0) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }

      const customer = result.rows[0];
      const valid = await bcrypt.compare(password, customer.password_hash);

      if (!valid) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }

      // Update last login
      await pool.query('UPDATE customers SET last_login_at = NOW() WHERE id = $1', [customer.id]);

      const token = generateToken(customer.id, customer.email);

      // Don't send password hash
      delete customer.password_hash;

      res.json({ customer, token });
    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  /**
   * GET /api/auth/verify
   */
  router.get('/verify', authenticate, async (req, res) => {
    try {
      const result = await pool.query(
        'SELECT id, email, business_name, industry, location, plan, status, credits_balance, brand_colors, visual_style, tone, avatar_id, voice_id, preferred_image_provider FROM customers WHERE id = $1',
        [req.customerId]
      );

      if (result.rows.length === 0) {
        return res.status(404).json({ error: 'Customer not found' });
      }

      res.json({ customer: result.rows[0] });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  return router;
};
