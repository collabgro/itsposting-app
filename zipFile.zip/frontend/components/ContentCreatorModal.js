import { useState, useEffect } from 'react';
import {
  X, Sparkles, Loader2, Image as ImageIcon,
  Video, LayoutGrid, FileText, Zap, DollarSign,
} from 'lucide-react';
import { contentAPI } from '../lib/api';
import toast from 'react-hot-toast';

const CONTENT_TYPES = [
  {
    id: 'static',
    name: 'Text Card',
    icon: FileText,
    credits: 1,
    description: 'Styled text on branded background',
    example: 'Quick tip about driveway maintenance',
  },
  {
    id: 'photo',
    name: 'Photo Post',
    icon: ImageIcon,
    credits: 3,
    description: 'AI-generated photo (NanoBanana or Midjourney)',
    example: 'Show a freshly poured concrete driveway',
  },
  {
    id: 'carousel',
    name: 'Carousel',
    icon: LayoutGrid,
    credits: 5,
    description: '5-slide educational carousel',
    example: '5 tips for spring concrete maintenance',
  },
  {
    id: 'video',
    name: 'Video',
    icon: Video,
    credits: 10,
    description: '30-second AI avatar video',
    example: 'Explain our concrete services',
  },
];

export default function ContentCreatorModal({ onClose, onSuccess }) {
  const [step, setStep] = useState(1);
  const [contentType, setContentType] = useState('');
  const [prompt, setPrompt] = useState('');
  const [generating, setGenerating] = useState(false);
  const [generatedContent, setGeneratedContent] = useState(null);
  const [credits, setCredits] = useState(null);
  const [providers, setProviders] = useState(null);

  useEffect(() => {
    contentAPI.getCredits().then((res) => setCredits(res.data)).catch(() => {});
    contentAPI.getProviders().then((res) => setProviders(res.data)).catch(() => {});
  }, []);

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      toast.error('Please enter a prompt');
      return;
    }

    setGenerating(true);
    setStep(3);

    try {
      const response = await contentAPI.generate({ contentType, prompt });
      setGeneratedContent(response.data);
      setCredits((prev) => ({ ...prev, balance: response.data.creditsRemaining }));
      setStep(4);
      toast.success(`Generated with ${response.data.provider}!`);
    } catch (error) {
      toast.error(error.response?.data?.error || 'Generation failed');
      setStep(2);
    } finally {
      setGenerating(false);
    }
  };

  const handleSave = () => {
    toast.success('Post saved!');
    onSuccess();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto animate-slide-in">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200 sticky top-0 bg-white z-10">
          <div className="flex items-center gap-3">
            <Sparkles className="w-6 h-6 text-primary-500" />
            <div>
              <h2 className="text-xl font-bold text-gray-900">Create Custom Post</h2>
              {credits && (
                <p className="text-sm text-gray-600">
                  {credits.balance} credits available
                </p>
              )}
            </div>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6">
          {/* Step 1: Choose type */}
          {step === 1 && (
            <div className="space-y-6 animate-fade-in">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Choose content type</h3>
                <p className="text-gray-600">What would you like to create?</p>
              </div>

              {/* Provider info */}
              {providers && (
                <div className="bg-gradient-to-r from-yellow-50 to-orange-50 border border-yellow-200 rounded-lg p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Zap className="w-5 h-5 text-yellow-600" />
                    <span className="font-semibold text-yellow-900">Active Image Providers</span>
                  </div>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div className={`flex items-center gap-2 ${providers.nanobanana?.available ? 'text-green-700' : 'text-gray-400'}`}>
                      <span>{providers.nanobanana?.available ? '✅' : '⚠️'}</span>
                      <span>🍌 NanoBanana ({providers.nanobanana?.speed})</span>
                    </div>
                    <div className={`flex items-center gap-2 ${providers.midjourney?.available ? 'text-green-700' : 'text-gray-400'}`}>
                      <span>{providers.midjourney?.available ? '✅' : '⚠️'}</span>
                      <span>🎨 Midjourney ({providers.midjourney?.speed})</span>
                    </div>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {CONTENT_TYPES.map((type) => {
                  const Icon = type.icon;
                  const canAfford = !credits || credits.balance >= type.credits;

                  return (
                    <button
                      key={type.id}
                      onClick={() => {
                        if (canAfford) {
                          setContentType(type.id);
                          setStep(2);
                        } else {
                          toast.error('Insufficient credits');
                        }
                      }}
                      disabled={!canAfford}
                      className={`p-6 border-2 rounded-lg text-left transition-all ${
                        !canAfford
                          ? 'border-gray-200 opacity-50 cursor-not-allowed'
                          : 'border-gray-200 hover:border-primary-500 hover:bg-primary-50'
                      }`}
                    >
                      <div className="flex items-start justify-between mb-3">
                        <Icon className={`w-8 h-8 ${!canAfford ? 'text-gray-400' : 'text-primary-500'}`} />
                        <span className="px-3 py-1 rounded-full text-sm font-medium font-mono bg-primary-100 text-primary-700">
                          {type.credits} credits
                        </span>
                      </div>
                      <h4 className="font-bold text-gray-900 mb-1">{type.name}</h4>
                      <p className="text-sm text-gray-600 mb-2">{type.description}</p>
                      <p className="text-xs text-gray-500 italic">"{type.example}"</p>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Step 2: Enter prompt */}
          {step === 2 && (
            <div className="space-y-6 animate-fade-in">
              <button
                onClick={() => setStep(1)}
                className="text-sm text-primary-600 hover:text-primary-700"
              >
                ← Change content type
              </button>

              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  What would you like to create?
                </h3>
                <p className="text-gray-600">
                  Describe your {CONTENT_TYPES.find((t) => t.id === contentType)?.name.toLowerCase()}
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Your Prompt</label>
                <textarea
                  className="input min-h-[150px]"
                  placeholder={`Example: ${CONTENT_TYPES.find((t) => t.id === contentType)?.example}`}
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                />
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-800 font-medium">💡 Tips for great prompts:</p>
                <ul className="text-sm text-blue-700 mt-2 space-y-1 ml-4 list-disc">
                  <li>Be specific about what to show</li>
                  <li>Mention your location for relevance</li>
                  <li>Include any key details</li>
                </ul>
              </div>

              <div className="flex justify-between items-center pt-4 border-t">
                <p className="text-sm text-gray-600 flex items-center gap-2">
                  <DollarSign className="w-4 h-4" />
                  Cost: <strong>{CONTENT_TYPES.find((t) => t.id === contentType)?.credits} credits</strong>
                </p>
                <button onClick={handleGenerate} className="btn btn-primary">
                  <Sparkles className="w-4 h-4 mr-2" />
                  Generate
                </button>
              </div>
            </div>
          )}

          {/* Step 3: Generating */}
          {step === 3 && (
            <div className="py-12 text-center animate-fade-in">
              <Loader2 className="w-16 h-16 text-primary-500 animate-spin mx-auto mb-6" />
              <h3 className="text-xl font-bold text-gray-900 mb-2">
                Creating your {CONTENT_TYPES.find((t) => t.id === contentType)?.name.toLowerCase()}...
              </h3>
              <p className="text-gray-600">This takes 10-30 seconds</p>
              <div className="max-w-md mx-auto mt-6 space-y-2">
                {[
                  'Analyzing your prompt',
                  'Generating caption with Claude',
                  contentType === 'video' ? 'Creating video with HeyGen' : 'Generating image',
                  'Finalizing your post',
                ].map((s, idx) => (
                  <div key={idx} className="flex items-center gap-3 text-left">
                    <div className="w-5 h-5 rounded-full border-2 border-primary-300 flex-shrink-0" />
                    <span className="text-sm text-gray-600">{s}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Step 4: Preview */}
          {step === 4 && generatedContent && (
            <div className="space-y-6 animate-fade-in">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">Preview your post</h3>
                <span className="text-sm text-gray-600 capitalize">
                  Generated by: <strong>{generatedContent.provider}</strong>
                </span>
              </div>

              {/* Media preview */}
              <div className="bg-gray-100 rounded-lg p-4">
                {contentType === 'video' ? (
                  <video src={generatedContent.mediaUrl} controls className="w-full max-w-md mx-auto rounded-lg" />
                ) : contentType === 'carousel' ? (
                  <div className="grid grid-cols-5 gap-2 max-w-2xl mx-auto">
                    {generatedContent.slides?.map((slide, idx) => (
                      <img
                        key={idx}
                        src={slide.mediaUrl}
                        alt={`Slide ${idx + 1}`}
                        className="w-full aspect-square object-cover rounded"
                      />
                    ))}
                  </div>
                ) : (
                  <img
                    src={generatedContent.mediaUrl}
                    alt="Generated"
                    className="w-full max-w-md mx-auto rounded-lg"
                  />
                )}
              </div>

              {/* Caption */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Caption</label>
                <textarea
                  className="input min-h-[120px]"
                  value={generatedContent.caption}
                  onChange={(e) =>
                    setGeneratedContent({ ...generatedContent, caption: e.target.value })
                  }
                />
              </div>

              {/* Hashtags */}
              {generatedContent.hashtags && generatedContent.hashtags.length > 0 && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Hashtags</label>
                  <div className="flex flex-wrap gap-2">
                    {generatedContent.hashtags.map((tag, idx) => (
                      <span
                        key={idx}
                        className="px-3 py-1 bg-primary-100 text-primary-700 rounded-full text-sm"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex justify-between items-center pt-4 border-t">
                <p className="text-sm text-gray-600">
                  Credits left: <strong className="font-mono">{generatedContent.creditsRemaining}</strong>
                </p>
                <div className="flex gap-3">
                  <button onClick={() => setStep(2)} className="btn btn-secondary">
                    Try Again
                  </button>
                  <button onClick={handleSave} className="btn btn-primary">
                    Save Post
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
