import { MoreVertical } from 'lucide-react';

interface Post {
  id: number;
  thumbnail: string;
  caption: string;
  platforms: ('facebook' | 'instagram' | 'google')[];
  status: 'published' | 'scheduled' | 'draft';
  date: string;
}

interface RecentPostsProps {
  showEmpty?: boolean;
  onGenerateClick: () => void;
}

const mockPosts: Post[] = [
  {
    id: 1,
    thumbnail: '🥐',
    caption: 'Fresh croissants baked daily! Stop by for breakfast treats that melt in your mouth.',
    platforms: ['facebook', 'instagram', 'google'],
    status: 'published',
    date: 'May 1, 2026'
  },
  {
    id: 2,
    thumbnail: '🎂',
    caption: 'Custom birthday cakes now available for pre-order. Make your celebration sweet!',
    platforms: ['facebook', 'instagram'],
    status: 'scheduled',
    date: 'May 3, 2026'
  },
  {
    id: 3,
    thumbnail: '☕',
    caption: 'Weekend special: Buy any pastry, get a coffee at 50% off!',
    platforms: ['google'],
    status: 'draft',
    date: 'May 5, 2026'
  }
];

const statusStyles = {
  published: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  scheduled: 'bg-amber-100 text-amber-700 border-amber-200',
  draft: 'bg-gray-100 text-gray-700 border-gray-200'
};

const platformIcons = {
  facebook: '📘',
  instagram: '📷',
  google: '🔍'
};

export function RecentPosts({ showEmpty = true, onGenerateClick }: RecentPostsProps) {
  if (showEmpty) {
    return (
      <div className="bg-white rounded-2xl border border-gray-200 p-12">
        <div className="flex flex-col items-center justify-center text-center max-w-md mx-auto">
          <div className="mb-6 relative">
            <div className="text-7xl opacity-20">📱</div>
            <div className="absolute -top-2 -right-2 text-4xl">✨</div>
          </div>

          <h3 className="text-xl font-semibold text-gray-900 mb-2">No posts yet</h3>
          <p className="text-gray-600 mb-6">
            Create your first AI-powered post above!
          </p>

          <button
            onClick={onGenerateClick}
            className="px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors flex items-center gap-2"
          >
            <span className="text-lg">✦</span>
            <span>Generate with AI</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Post</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Platforms</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {mockPosts.map((post) => (
              <tr key={post.id} className="hover:bg-gray-50 transition-colors">
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-indigo-100 to-violet-100 flex items-center justify-center text-2xl">
                      {post.thumbnail}
                    </div>
                    <div className="max-w-md">
                      <p className="text-sm text-gray-900 line-clamp-2">{post.caption}</p>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="flex gap-1">
                    {post.platforms.map((platform) => (
                      <span key={platform} className="text-lg" title={platform}>
                        {platformIcons[platform]}
                      </span>
                    ))}
                  </div>
                </td>
                <td className="px-6 py-4">
                  <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium border ${statusStyles[post.status]}`}>
                    {post.status.charAt(0).toUpperCase() + post.status.slice(1)}
                  </span>
                </td>
                <td className="px-6 py-4 text-sm text-gray-600">{post.date}</td>
                <td className="px-6 py-4">
                  <button className="p-1 hover:bg-gray-100 rounded transition-colors">
                    <MoreVertical size={18} className="text-gray-500" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
