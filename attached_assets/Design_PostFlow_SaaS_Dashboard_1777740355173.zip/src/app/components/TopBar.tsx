import { ChevronLeft, Sun, Moon } from 'lucide-react';
import { useTheme } from './ThemeProvider';

interface TopBarProps {
  title: string;
  subtitle?: string;
  onCreatePost?: () => void;
  showBackButton?: boolean;
}

export function TopBar({ title, subtitle, onCreatePost, showBackButton = false }: TopBarProps) {
  const { theme, toggleTheme } = useTheme();

  return (
    <div className="h-16 bg-background border-b border-border px-6 flex items-center justify-between">
      <div className="flex items-center gap-4">
        {showBackButton && (
          <button className="w-8 h-8 rounded-lg hover:bg-muted flex items-center justify-center transition-colors">
            <ChevronLeft size={20} className="text-foreground" />
          </button>
        )}
        <div>
          <h1 className="text-xl font-semibold text-foreground">{title}</h1>
          {subtitle && <p className="text-sm text-muted-foreground">{subtitle}</p>}
        </div>
      </div>

      <div className="flex items-center gap-3">
        <button
          onClick={toggleTheme}
          className="w-9 h-9 rounded-lg hover:bg-muted flex items-center justify-center transition-colors"
          title={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`}
        >
          {theme === 'light' ? (
            <Moon size={18} className="text-foreground" />
          ) : (
            <Sun size={18} className="text-foreground" />
          )}
        </button>

        {onCreatePost && (
          <button
            onClick={onCreatePost}
            className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:opacity-90 transition-opacity flex items-center gap-2"
          >
            <div className="w-4 h-4 rounded-full border-2 border-current flex items-center justify-center">
              <span className="text-xs">+</span>
            </div>
            <span className="text-sm font-medium">Create new post</span>
          </button>
        )}
      </div>
    </div>
  );
}
