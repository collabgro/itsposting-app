import { useState } from 'react';
import { useRouter } from 'next/router';
import Link from 'next/link';
import { Mail, Lock, Sparkles, Loader2 } from 'lucide-react';
import { useAuthStore } from '../lib/store';
import { authAPI } from '../lib/api';
import toast from 'react-hot-toast';

export default function Login() {
  const router = useRouter();
  const login = useAuthStore((state) => state.login);

  const [formData, setFormData] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await authAPI.login(formData);
      const { customer, token } = response.data;
      login(customer, token);
      toast.success('Welcome back!');
      router.push('/dashboard');
    } catch (error) {
      toast.error(error.response?.data?.error || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex">
      {/* Left side */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-primary-600 to-accent-600 p-12 flex-col justify-between">
        <div className="flex items-center gap-3 text-white">
          <Sparkles className="w-10 h-10" />
          <h1 className="text-3xl font-bold">PostFlow</h1>
        </div>

        <div className="text-white space-y-6">
          <h2 className="text-4xl font-bold leading-tight">
            AI creates your<br />social media.<br />Forever.
          </h2>
          <p className="text-lg text-white/90">
            Stop spending hours on social media. Let AI handle it while you focus on your business.
          </p>

          <div className="space-y-4 mt-8">
            {[
              { title: 'Auto-generated content', desc: 'Daily posts created and scheduled automatically' },
              { title: 'NanoBanana + Midjourney', desc: 'Choose between fast or premium image generation' },
              { title: 'Multi-platform posting', desc: 'Facebook, Instagram, Google Business in one place' },
            ].map((feat, idx) => (
              <div key={idx} className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <div className="w-2 h-2 rounded-full bg-white"></div>
                </div>
                <div>
                  <p className="font-medium">{feat.title}</p>
                  <p className="text-sm text-white/80">{feat.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <p className="text-white/60 text-sm">Trusted by 1,000+ local businesses</p>
      </div>

      {/* Right side */}
      <div className="flex-1 flex items-center justify-center p-8 bg-white">
        <div className="w-full max-w-md">
          <div className="lg:hidden mb-8">
            <div className="flex items-center gap-3 text-primary-600">
              <Sparkles className="w-8 h-8" />
              <h1 className="text-2xl font-bold">PostFlow</h1>
            </div>
          </div>

          <div className="mb-8">
            <h2 className="text-3xl font-bold text-gray-900">Welcome back</h2>
            <p className="text-gray-600 mt-2">Sign in to your account</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="email"
                  required
                  className="input pl-10"
                  placeholder="you@company.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="password"
                  required
                  className="input pl-10"
                  placeholder="••••••••"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="btn btn-primary w-full disabled:opacity-50"
            >
              {loading ? (
                <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Signing in...</>
              ) : (
                'Sign in'
              )}
            </button>
          </form>

          <p className="mt-8 text-center text-gray-600">
            Don't have an account?{' '}
            <Link href="/signup" className="text-primary-600 font-medium hover:text-primary-700">
              Start free trial
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
