import { Home, TrendingUp, Calendar, BookOpen, Folder, Settings, HelpCircle, MessageSquare, Bell, ChevronDown, Zap } from 'lucide-react';

interface SidebarProps {
  activeView: string;
  onNavigate: (view: string) => void;
}

export function Sidebar({ activeView, onNavigate }: SidebarProps) {
  const navItems = [
    { id: 'dashboard', icon: Home, label: 'Dashboard' },
    { id: 'analytics', icon: TrendingUp, label: 'Analytics' },
    { id: 'publishing', icon: Calendar, label: 'Publishing', hasSubmenu: true },
    { id: 'drafts', icon: BookOpen, label: 'Drafts' },
    { id: 'media', icon: Folder, label: 'Media library' },
  ];

  const bottomItems = [
    { id: 'help', icon: HelpCircle, label: 'Help' },
    { id: 'feedback', icon: MessageSquare, label: 'Feedback' },
    { id: 'notifications', icon: Bell, label: 'Notifications' },
  ];

  return (
    <div className="w-[220px] bg-sidebar border-r border-sidebar-border flex flex-col h-screen">
      <div className="p-4 border-b border-sidebar-border">
        <div className="flex items-center gap-2 mb-4">
          <div className="w-8 h-8 bg-gradient-to-br from-purple-500 via-violet-500 to-pink-500 rounded-lg flex items-center justify-center">
            <div className="w-5 h-5 grid grid-cols-2 gap-0.5">
              <div className="w-2 h-2 bg-white rounded-full"></div>
              <div className="w-2 h-2 bg-white/70 rounded-full"></div>
              <div className="w-2 h-2 bg-white/70 rounded-full"></div>
              <div className="w-2 h-2 bg-white/50 rounded-full"></div>
            </div>
          </div>
          <span className="font-semibold text-sidebar-foreground">PostFlow</span>
        </div>

        <button className="w-full flex items-center justify-between px-3 py-2 bg-sidebar-accent rounded-lg hover:bg-sidebar-accent/80 transition-colors">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-gradient-to-br from-indigo-500 to-purple-500 rounded flex items-center justify-center text-white text-xs font-semibold">
              T
            </div>
            <div className="text-left">
              <div className="text-sm font-medium text-sidebar-foreground">Test</div>
              <div className="text-xs text-muted-foreground">Group</div>
            </div>
          </div>
          <ChevronDown size={16} className="text-muted-foreground" />
        </button>
      </div>

      <div className="px-3 py-4 border-b border-sidebar-border">
        <button
          onClick={() => onNavigate('create')}
          className="w-full flex items-center gap-2 px-3 py-2 text-sm text-muted-foreground hover:text-sidebar-foreground transition-colors rounded-lg hover:bg-sidebar-accent"
        >
          <div className="w-5 h-5 rounded-full border-2 border-muted-foreground/50 flex items-center justify-center">
            <span className="text-xs">+</span>
          </div>
          <span>Create new post</span>
        </button>
      </div>

      <nav className="flex-1 px-3 py-4 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-lg transition-all text-sm ${
                isActive
                  ? 'bg-sidebar-primary text-sidebar-primary-foreground'
                  : 'text-muted-foreground hover:text-sidebar-foreground hover:bg-sidebar-accent'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon size={18} />
                <span>{item.label}</span>
              </div>
              {item.hasSubmenu && <ChevronDown size={16} className={isActive ? '' : 'opacity-50'} />}
            </button>
          );
        })}
      </nav>

      <div className="px-3 py-2 border-t border-sidebar-border">
        <button
          onClick={() => onNavigate('settings')}
          className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-all text-sm mb-2 ${
            activeView === 'settings'
              ? 'bg-sidebar-primary text-sidebar-primary-foreground'
              : 'text-muted-foreground hover:text-sidebar-foreground hover:bg-sidebar-accent'
          }`}
        >
          <Settings size={18} />
          <span>Settings</span>
        </button>
      </div>

      <div className="p-3 border-t border-sidebar-border space-y-1">
        <div className="px-3 py-2 bg-sidebar-accent rounded-lg mb-2">
          <div className="text-xs font-medium text-sidebar-foreground">Free trial version</div>
          <div className="text-xs text-muted-foreground">7 days left</div>
        </div>
        <button className="w-full px-3 py-1.5 bg-primary text-primary-foreground rounded-lg text-xs font-medium hover:opacity-90 transition-opacity">
          Upgrade now
        </button>
      </div>

      <div className="px-3 py-2 border-t border-sidebar-border space-y-1">
        {bottomItems.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-muted-foreground hover:text-sidebar-foreground hover:bg-sidebar-accent transition-all"
            >
              <Icon size={18} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>

      <div className="p-3 border-t border-sidebar-border">
        <button className="w-full flex items-center gap-3 px-2 py-2 hover:bg-sidebar-accent rounded-lg transition-colors group">
          <div className="w-8 h-8 bg-gradient-to-br from-orange-400 to-orange-600 rounded-full flex items-center justify-center text-white text-sm font-semibold">
            CG
          </div>
          <div className="flex-1 text-left">
            <div className="text-sm font-medium text-sidebar-foreground">Collab Gro</div>
            <div className="text-xs text-muted-foreground truncate">collabgroo@gmail.com</div>
          </div>
          <ChevronDown size={16} className="text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
        </button>
      </div>
    </div>
  );
}
