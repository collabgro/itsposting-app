import { Eye, Heart, MessageCircle, Share2 } from 'lucide-react';

interface DashboardViewProps {
  onCreatePost: () => void;
}

export function DashboardView({ onCreatePost }: DashboardViewProps) {
  const daysOfWeek = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
  const calendarDays = Array.from({ length: 35 }, (_, i) => ({
    day: i < 3 ? 28 + i : i > 30 ? i - 30 : i - 2,
    isCurrentMonth: i >= 3 && i <= 30,
    isToday: i === 4
  }));

  return (
    <div className="grid grid-cols-3 gap-6">
      <div className="bg-card border border-border rounded-xl p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-foreground" />
            <h3 className="font-semibold text-foreground">May overview</h3>
          </div>
          <button className="px-3 py-1 bg-muted text-foreground rounded-lg text-sm hover:bg-muted/80 transition-colors">
            Calendar
          </button>
        </div>

        <div className="space-y-2">
          <div className="grid grid-cols-7 gap-1 mb-2">
            {daysOfWeek.map(day => (
              <div key={day} className="text-center text-xs text-muted-foreground uppercase">
                {day}
              </div>
            ))}
          </div>
          <div className="grid grid-cols-7 gap-1">
            {calendarDays.map((dayInfo, idx) => (
              <div
                key={idx}
                className={`aspect-square rounded-lg flex items-center justify-center text-sm ${
                  !dayInfo.isCurrentMonth
                    ? 'text-muted-foreground/30'
                    : dayInfo.isToday
                    ? 'bg-primary text-primary-foreground font-semibold'
                    : 'text-foreground hover:bg-muted transition-colors cursor-pointer'
                }`}
              >
                {dayInfo.day}
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="col-span-2 bg-card border border-border rounded-xl p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-foreground" />
            <h3 className="font-semibold text-foreground">Best reach</h3>
          </div>
          <div className="flex gap-2">
            <button className="px-3 py-1 bg-muted text-foreground rounded-lg text-sm hover:bg-muted/80 transition-colors">
              week
            </button>
            <button className="px-3 py-1 text-muted-foreground rounded-lg text-sm hover:bg-muted transition-colors">
              month
            </button>
            <button className="px-3 py-1 text-muted-foreground rounded-lg text-sm hover:bg-muted transition-colors">
              Content analytics
            </button>
          </div>
        </div>

        <div className="grid grid-cols-4 gap-4 mb-8">
          <MetricCard icon={Eye} label="Views" value="0" />
          <MetricCard icon={Heart} label="Likes" value="0" />
          <MetricCard icon={MessageCircle} label="Replies" value="0" />
          <MetricCard icon={Share2} label="Shares" value="0" />
        </div>

        <div className="flex flex-col items-center justify-center py-12">
          <div className="w-20 h-20 bg-muted/50 rounded-full flex items-center justify-center mb-4">
            <TrendingUp className="w-10 h-10 text-muted-foreground/50" />
          </div>
          <h4 className="text-lg font-semibold text-foreground mb-2">No posts this month</h4>
          <p className="text-sm text-muted-foreground mb-6">
            Schedule and publish your first post
          </p>
          <button
            onClick={onCreatePost}
            className="px-4 py-2 bg-muted text-foreground rounded-lg hover:bg-muted/80 transition-colors flex items-center gap-2"
          >
            <div className="w-4 h-4 rounded-full border-2 border-current flex items-center justify-center">
              <span className="text-xs">+</span>
            </div>
            <span className="text-sm">Schedule first post</span>
          </button>
        </div>
      </div>

      <div className="col-span-3 grid grid-cols-2 gap-6">
        <div className="bg-card border border-border rounded-xl p-6">
          <div className="flex items-center gap-2 mb-4">
            <BookOpen className="w-5 h-5 text-foreground" />
            <h3 className="font-semibold text-foreground">Post details</h3>
          </div>

          <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg hover:bg-muted transition-colors cursor-pointer">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                <Calendar className="w-5 h-5 text-primary" />
              </div>
              <div>
                <div className="text-sm font-medium text-foreground">Scheduled groups</div>
                <div className="text-xs text-muted-foreground">Scheduled posts</div>
              </div>
            </div>
            <div className="text-right">
              <div className="text-lg font-semibold text-foreground">0</div>
              <div className="text-xs text-muted-foreground">0</div>
            </div>
          </div>
        </div>

        <div className="bg-card border border-border rounded-xl p-6">
          <div className="flex items-center gap-2 mb-4">
            <Clock className="w-5 h-5 text-foreground" />
            <h3 className="font-semibold text-foreground">Upcoming posts</h3>
          </div>

          <div className="flex flex-col items-center justify-center py-8">
            <h4 className="text-base font-medium text-foreground mb-1">No upcoming posts</h4>
            <p className="text-sm text-muted-foreground">
              Create and schedule your first post
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function MetricCard({ icon: Icon, label, value }: { icon: any; label: string; value: string }) {
  return (
    <div className="flex items-center gap-2">
      <Icon size={16} className="text-muted-foreground" />
      <div className="text-sm text-muted-foreground">{label}</div>
    </div>
  );
}

import { Calendar, TrendingUp, BookOpen, Clock } from 'lucide-react';
