require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const { Pool } = require('pg');

// Routes
const authRoutes = require('./routes/auth');
const customerRoutes = require('./routes/customers');
const postRoutes = require('./routes/posts');
const contentRoutes = require('./routes/content');

const app = express();
const PORT = process.env.PORT || 3001;

// Database
const pool = new Pool({
  connectionString: process.env.DATABASE_URL || 'postgresql://localhost:5432/socialmedia',
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000,
});

pool.query('SELECT NOW()', (err, res) => {
  if (err) {
    console.error('❌ Database connection error:', err.message);
    console.error('Make sure PostgreSQL is running and DATABASE_URL is correct');
  } else {
    console.log('✅ Database connected at', res.rows[0].now);
  }
});

// Security
app.use(helmet({
  contentSecurityPolicy: false, // Allow inline scripts for development
}));
app.use(compression());

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  message: 'Too many requests, please try again later.',
});
app.use('/api/', limiter);

// CORS
app.use(cors({
  origin: process.env.FRONTEND_URL || ['http://localhost:3000', 'http://localhost:5173'],
  credentials: true,
}));

// Body parsing
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Logging
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
  next();
});

// Mount routes
app.use('/api/auth', authRoutes(pool));
app.use('/api/customers', customerRoutes(pool));
app.use('/api/posts', postRoutes(pool));
app.use('/api/content', contentRoutes(pool));

// Health check
app.get('/health', async (req, res) => {
  try {
    await pool.query('SELECT 1');
    res.json({
      status: 'ok',
      timestamp: new Date().toISOString(),
      database: 'connected',
      version: '2.0.0',
      services: {
        anthropic: !!process.env.ANTHROPIC_API_KEY,
        nanobanana: !!process.env.GOOGLE_AI_API_KEY,
        midjourney: !!process.env.REPLICATE_API_TOKEN,
        heygen: !!process.env.HEYGEN_API_KEY,
        cloudinary: !!process.env.CLOUDINARY_CLOUD_NAME,
      },
    });
  } catch (error) {
    res.status(503).json({
      status: 'error',
      database: 'disconnected',
      error: error.message,
    });
  }
});

// Root
app.get('/', (req, res) => {
  res.json({
    name: 'PostFlow API',
    version: '2.0.0',
    docs: '/health',
    endpoints: {
      auth: '/api/auth/*',
      customers: '/api/customers/*',
      posts: '/api/posts/*',
      content: '/api/content/*',
    },
  });
});

// Error handling
app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.status(err.status || 500).json({
    error: err.message || 'Internal server error',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack }),
  });
});

app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

// Start server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`
╔═══════════════════════════════════════════╗
║   🚀 PostFlow API Server                  ║
║                                           ║
║   📊 Port: ${PORT}                            ║
║   🌍 Env: ${(process.env.NODE_ENV || 'development').padEnd(11)}                    ║
║                                           ║
║   AI Services:                            ║
║   ${process.env.ANTHROPIC_API_KEY ? '✅' : '⚠️ '} Anthropic (Claude)                  ║
║   ${process.env.GOOGLE_AI_API_KEY ? '✅' : '⚠️ '} NanoBanana (Gemini)                 ║
║   ${process.env.REPLICATE_API_TOKEN ? '✅' : '⚠️ '} Midjourney (Replicate)              ║
║   ${process.env.HEYGEN_API_KEY ? '✅' : '⚠️ '} HeyGen (Video)                      ║
║   ${process.env.CLOUDINARY_CLOUD_NAME ? '✅' : '⚠️ '} Cloudinary (Storage)                ║
║                                           ║
╚═══════════════════════════════════════════╝
  `);
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('SIGTERM received, shutting down...');
  await pool.end();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('\nSIGINT received, shutting down...');
  await pool.end();
  process.exit(0);
});

module.exports = { pool };
