import { X, Sparkles } from 'lucide-react';
import { useState } from 'react';

interface ContentCreatorModalProps {
  onClose: () => void;
}

export function ContentCreatorModal({ onClose }: ContentCreatorModalProps) {
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>(['facebook']);
  const [contentType, setContentType] = useState('text');
  const [tone, setTone] = useState('friendly');
  const [prompt, setPrompt] = useState('');

  const platforms = [
    { id: 'facebook', label: 'Facebook', icon: '📘' },
    { id: 'instagram', label: 'Instagram', icon: '📷' },
    { id: 'google', label: 'Google Business', icon: '🔍' }
  ];

  const contentTypes = [
    { id: 'text', label: 'Text Card', credits: 1, icon: '💬' },
    { id: 'photo', label: 'Photo', credits: 3, icon: '📸' },
    { id: 'carousel', label: 'Carousel', credits: 5, icon: '🎠' },
    { id: 'video', label: 'Video', credits: 10, icon: '🎬' }
  ];

  const tones = [
    { id: 'professional', label: 'Professional' },
    { id: 'friendly', label: 'Friendly' },
    { id: 'playful', label: 'Playful' },
    { id: 'urgent', label: 'Urgent' }
  ];

  const promptSuggestions = [
    'New product launch',
    'Customer testimonial',
    'Weekly special',
    'Behind the scenes',
    'Seasonal promotion'
  ];

  const togglePlatform = (platformId: string) => {
    setSelectedPlatforms(prev =>
      prev.includes(platformId)
        ? prev.filter(p => p !== platformId)
        : [...prev, platformId]
    );
  };

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4 backdrop-blur-sm">
      <div className="bg-card border border-border rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col shadow-2xl">
        <div className="p-6 border-b border-border flex items-center justify-between">
          <div>
            <h2 className="text-xl font-semibold text-foreground">Create AI Content</h2>
            <p className="text-sm text-muted-foreground mt-1">
              Generate engaging content with AI assistance
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-muted rounded-lg transition-colors"
          >
            <X size={20} className="text-foreground" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-foreground mb-3">
                What's your post about?
              </label>
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Describe what you want to post about..."
                className="w-full h-32 px-4 py-3 bg-input-background border border-input rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring resize-none"
              />
              <div className="flex flex-wrap gap-2 mt-3">
                {promptSuggestions.map((suggestion) => (
                  <button
                    key={suggestion}
                    onClick={() => setPrompt(suggestion)}
                    className="px-3 py-1.5 bg-muted hover:bg-muted/80 text-foreground rounded-full text-sm transition-colors"
                  >
                    {suggestion}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-foreground mb-3">
                Select Platforms
              </label>
              <div className="grid grid-cols-3 gap-3">
                {platforms.map((platform) => (
                  <button
                    key={platform.id}
                    onClick={() => togglePlatform(platform.id)}
                    className={`px-4 py-3 rounded-lg border-2 transition-all ${
                      selectedPlatforms.includes(platform.id)
                        ? 'border-primary bg-primary/10'
                        : 'border-border bg-card hover:border-muted-foreground/30'
                    }`}
                  >
                    <div className="text-2xl mb-1">{platform.icon}</div>
                    <div className="text-xs text-foreground">{platform.label}</div>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-foreground mb-3">
                Content Type
              </label>
              <div className="grid grid-cols-4 gap-2">
                {contentTypes.map((type) => (
                  <button
                    key={type.id}
                    onClick={() => setContentType(type.id)}
                    className={`px-3 py-3 rounded-lg border-2 transition-all ${
                      contentType === type.id
                        ? 'border-primary bg-primary/10'
                        : 'border-border bg-card hover:border-muted-foreground/30'
                    }`}
                  >
                    <div className="text-2xl mb-1">{type.icon}</div>
                    <div className="text-xs font-medium text-foreground">{type.label}</div>
                    <div className="text-xs text-muted-foreground mt-1">{type.credits} credits</div>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-foreground mb-3">
                Tone
              </label>
              <div className="grid grid-cols-4 gap-2">
                {tones.map((t) => (
                  <button
                    key={t.id}
                    onClick={() => setTone(t.id)}
                    className={`px-4 py-2 rounded-lg border-2 text-sm transition-all ${
                      tone === t.id
                        ? 'border-primary bg-primary/10 text-foreground'
                        : 'border-border bg-card text-foreground hover:border-muted-foreground/30'
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="p-6 border-t border-border">
          <button className="w-full px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:opacity-90 transition-opacity flex items-center justify-center gap-2">
            <Sparkles size={18} />
            <span>Generate Content</span>
          </button>
        </div>
      </div>
    </div>
  );
}
