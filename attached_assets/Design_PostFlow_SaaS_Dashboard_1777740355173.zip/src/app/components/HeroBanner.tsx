export function HeroBanner() {
  return (
    <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-indigo-600 via-violet-600 to-purple-600 p-8">
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0" style={{
          backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)',
          backgroundSize: '24px 24px'
        }} />
      </div>

      <div className="relative flex items-center justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-2">
            <span className="text-3xl">🚀</span>
            <h2 className="text-2xl font-semibold text-white">Already have content?</h2>
          </div>
          <p className="text-indigo-100 text-base">
            Upload your own photos, videos, or carousels — no credits used!
          </p>
        </div>

        <button className="px-6 py-3 bg-transparent border-2 border-white text-white rounded-lg hover:bg-white/10 transition-all flex items-center gap-2">
          <span>Upload Now</span>
          <span>→</span>
        </button>
      </div>
    </div>
  );
}
