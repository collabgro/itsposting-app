import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import { Save, Loader2, Zap, Palette } from 'lucide-react';
import Layout from '../components/Layout';
import { customerAPI, contentAPI } from '../lib/api';
import { useAuthStore } from '../lib/store';
import toast from 'react-hot-toast';

const VISUAL_STYLES = [
  { id: 'modern', name: 'Modern', description: 'Clean, contemporary' },
  { id: 'professional', name: 'Professional', description: 'Polished, business' },
  { id: 'bold', name: 'Bold', description: 'Strong, vibrant' },
  { id: 'minimal', name: 'Minimal', description: 'Simple, elegant' },
];

const TONES = [
  { id: 'professional', name: 'Professional' },
  { id: 'friendly', name: 'Friendly' },
  { id: 'expert', name: 'Expert' },
  { id: 'casual', name: 'Casual' },
];

export default function Settings() {
  const router = useRouter();
  const { user, updateUser, isAuthenticated } = useAuthStore();

  const [profile, setProfile] = useState(null);
  const [providers, setProviders] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!isAuthenticated) {
      router.push('/login');
      return;
    }
    loadData();
  }, [isAuthenticated]);

  const loadData = async () => {
    try {
      const [profileRes, providersRes] = await Promise.all([
        customerAPI.getProfile(),
        contentAPI.getProviders().catch(() => ({ data: {} })),
      ]);
      setProfile(profileRes.data);
      setProviders(providersRes.data);
    } catch (error) {
      toast.error('Failed to load settings');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const res = await customerAPI.updateProfile({
        businessName: profile.business_name,
        industry: profile.industry,
        location: profile.location,
        phone: profile.phone,
        website: profile.website,
        brandColors: profile.brand_colors,
        visualStyle: profile.visual_style,
        tone: profile.tone,
        preferredImageProvider: profile.preferred_image_provider,
      });
      updateUser(res.data);
      toast.success('Settings saved!');
    } catch (error) {
      toast.error('Failed to save');
    } finally {
      setSaving(false);
    }
  };

  if (loading || !profile) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[400px]">
          <Loader2 className="w-12 h-12 text-primary-500 animate-spin" />
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Settings</h1>
            <p className="text-gray-600 mt-1">Manage your profile and preferences</p>
          </div>
          <button
            onClick={handleSave}
            disabled={saving}
            className="btn btn-primary disabled:opacity-50"
          >
            {saving ? (
              <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Saving...</>
            ) : (
              <><Save className="w-4 h-4 mr-2" /> Save Changes</>
            )}
          </button>
        </div>

        {/* Business Info */}
        <div className="card p-6">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Business Information</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Business Name</label>
              <input
                type="text"
                className="input"
                value={profile.business_name || ''}
                onChange={(e) => setProfile({ ...profile, business_name: e.target.value })}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Industry</label>
              <input
                type="text"
                className="input"
                value={profile.industry || ''}
                onChange={(e) => setProfile({ ...profile, industry: e.target.value })}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Location</label>
              <input
                type="text"
                className="input"
                value={profile.location || ''}
                onChange={(e) => setProfile({ ...profile, location: e.target.value })}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Phone</label>
              <input
                type="tel"
                className="input"
                value={profile.phone || ''}
                onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
              />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">Website</label>
              <input
                type="url"
                className="input"
                placeholder="https://"
                value={profile.website || ''}
                onChange={(e) => setProfile({ ...profile, website: e.target.value })}
              />
            </div>
          </div>
        </div>

        {/* Image Provider Selection */}
        <div className="card p-6">
          <div className="flex items-center gap-2 mb-4">
            <Zap className="w-5 h-5 text-yellow-500" />
            <h2 className="text-xl font-bold text-gray-900">Image Generation Provider</h2>
          </div>
          <p className="text-gray-600 mb-4 text-sm">
            Choose which AI service to use for generating images
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* NanoBanana */}
            <button
              onClick={() => setProfile({ ...profile, preferred_image_provider: 'nanobanana' })}
              disabled={!providers?.nanobanana?.available}
              className={`p-4 border-2 rounded-lg text-left transition-all ${
                profile.preferred_image_provider === 'nanobanana'
                  ? 'border-primary-500 bg-primary-50'
                  : 'border-gray-200 hover:border-gray-300'
              } ${!providers?.nanobanana?.available ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              <div className="flex items-start justify-between mb-2">
                <span className="text-2xl">🍌</span>
                {providers?.nanobanana?.available ? (
                  <span className="text-xs px-2 py-1 bg-green-100 text-green-700 rounded-full">Active</span>
                ) : (
                  <span className="text-xs px-2 py-1 bg-gray-100 text-gray-500 rounded-full">Not configured</span>
                )}
              </div>
              <h3 className="font-bold text-gray-900">NanoBanana</h3>
              <p className="text-xs text-gray-600 mt-1">Google Gemini 2.5 Flash Image</p>
              <div className="text-xs text-gray-500 mt-2 space-y-1">
                <div>⚡ {providers?.nanobanana?.speed || '3-8 seconds'}</div>
                <div>💰 ~$0.039/image</div>
                <div className="text-green-600 font-medium">✓ Recommended (cheaper, faster)</div>
              </div>
            </button>

            {/* Midjourney */}
            <button
              onClick={() => setProfile({ ...profile, preferred_image_provider: 'midjourney' })}
              disabled={!providers?.midjourney?.available}
              className={`p-4 border-2 rounded-lg text-left transition-all ${
                profile.preferred_image_provider === 'midjourney'
                  ? 'border-primary-500 bg-primary-50'
                  : 'border-gray-200 hover:border-gray-300'
              } ${!providers?.midjourney?.available ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              <div className="flex items-start justify-between mb-2">
                <span className="text-2xl">🎨</span>
                {providers?.midjourney?.available ? (
                  <span className="text-xs px-2 py-1 bg-green-100 text-green-700 rounded-full">Active</span>
                ) : (
                  <span className="text-xs px-2 py-1 bg-gray-100 text-gray-500 rounded-full">Not configured</span>
                )}
              </div>
              <h3 className="font-bold text-gray-900">Midjourney</h3>
              <p className="text-xs text-gray-600 mt-1">Premium quality via Replicate</p>
              <div className="text-xs text-gray-500 mt-2 space-y-1">
                <div>⏱ {providers?.midjourney?.speed || '15-20 seconds'}</div>
                <div>💰 ~$0.08/image</div>
                <div className="text-purple-600 font-medium">✨ Premium artistic quality</div>
              </div>
            </button>
          </div>
        </div>

        {/* Branding */}
        <div className="card p-6">
          <div className="flex items-center gap-2 mb-4">
            <Palette className="w-5 h-5 text-accent-500" />
            <h2 className="text-xl font-bold text-gray-900">Branding</h2>
          </div>

          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Primary Color</label>
                <div className="flex gap-2">
                  <input
                    type="color"
                    className="w-12 h-10 rounded border border-gray-300 cursor-pointer"
                    value={profile.brand_colors?.primary || '#3B82F6'}
                    onChange={(e) =>
                      setProfile({
                        ...profile,
                        brand_colors: { ...profile.brand_colors, primary: e.target.value },
                      })
                    }
                  />
                  <input
                    type="text"
                    className="input flex-1 font-mono text-sm"
                    value={profile.brand_colors?.primary || '#3B82F6'}
                    onChange={(e) =>
                      setProfile({
                        ...profile,
                        brand_colors: { ...profile.brand_colors, primary: e.target.value },
                      })
                    }
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Secondary Color</label>
                <div className="flex gap-2">
                  <input
                    type="color"
                    className="w-12 h-10 rounded border border-gray-300 cursor-pointer"
                    value={profile.brand_colors?.secondary || '#10B981'}
                    onChange={(e) =>
                      setProfile({
                        ...profile,
                        brand_colors: { ...profile.brand_colors, secondary: e.target.value },
                      })
                    }
                  />
                  <input
                    type="text"
                    className="input flex-1 font-mono text-sm"
                    value={profile.brand_colors?.secondary || '#10B981'}
                    onChange={(e) =>
                      setProfile({
                        ...profile,
                        brand_colors: { ...profile.brand_colors, secondary: e.target.value },
                      })
                    }
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Accent Color</label>
                <div className="flex gap-2">
                  <input
                    type="color"
                    className="w-12 h-10 rounded border border-gray-300 cursor-pointer"
                    value={profile.brand_colors?.accent || '#8B5CF6'}
                    onChange={(e) =>
                      setProfile({
                        ...profile,
                        brand_colors: { ...profile.brand_colors, accent: e.target.value },
                      })
                    }
                  />
                  <input
                    type="text"
                    className="input flex-1 font-mono text-sm"
                    value={profile.brand_colors?.accent || '#8B5CF6'}
                    onChange={(e) =>
                      setProfile({
                        ...profile,
                        brand_colors: { ...profile.brand_colors, accent: e.target.value },
                      })
                    }
                  />
                </div>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Visual Style</label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {VISUAL_STYLES.map((style) => (
                  <button
                    key={style.id}
                    onClick={() => setProfile({ ...profile, visual_style: style.id })}
                    className={`p-3 border-2 rounded-lg text-left transition-all ${
                      profile.visual_style === style.id
                        ? 'border-primary-500 bg-primary-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="font-medium text-sm">{style.name}</div>
                    <div className="text-xs text-gray-500">{style.description}</div>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Brand Tone</label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {TONES.map((tone) => (
                  <button
                    key={tone.id}
                    onClick={() => setProfile({ ...profile, tone: tone.id })}
                    className={`p-3 border-2 rounded-lg text-center transition-all ${
                      profile.tone === tone.id
                        ? 'border-primary-500 bg-primary-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="font-medium text-sm">{tone.name}</div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
