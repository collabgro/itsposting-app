
  # Design PostFlow SaaS Dashboard

  This is a code bundle for Design PostFlow SaaS Dashboard. The original project is available at https://www.figma.com/design/aTmeDM5VVVtbMUjK3qYDDe/Design-PostFlow-SaaS-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  